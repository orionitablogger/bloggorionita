<!-- =========================
     Page Breadcrumb   
============================== -->
<?php get_header(); ?>
<main id="content" class="single-class">
  <div class="container"> 
    <!--row-->
    <div class="row">
      <?php get_template_part('template-parts/content', 'single'); ?>
    </div>
    <!--/row-->
  </div>
  <!--/container-->
</main> 
<?php get_footer();